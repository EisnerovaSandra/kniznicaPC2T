package projektBP2T;

public class Roman extends Books{
	
	public enum Zaner{dobrodruzny, historicky, psychologicky, fantasticky, zivotopisny}
	public Zaner zaner;

	public Roman(String nazovKnihy, String autor, int rokVydania, Zaner zaner, boolean dostupnost) {
		super(nazovKnihy, autor, rokVydania, dostupnost);
		this.zaner = zaner;
	}
	
	public Zaner getZaner() {
		return zaner;
	}
	
	public void setZaner(Zaner zaner) {
	    this.zaner = zaner;
	  }
	
	@Override
	public String toString() {
		return "Nazov knihy: " + getNazov() + ", autor: " + getAutora() + ", rok vydania: " + getRok() + ", zaner: " + getZaner() + ", dostupnost: " + getDostupnost();
	}
	
	
}
