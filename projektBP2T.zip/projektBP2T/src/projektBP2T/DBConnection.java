package projektBP2T;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import projektBP2T.Roman.Zaner;

public class DBConnection {
	public static Connection con; 
	public boolean connect() { 
	       con= null; 
	       try {
	              con = DriverManager.getConnection("jdbc:sqlite:kniznica.db");                       
	       } 
	      catch (SQLException e) { 
	            System.out.println(e.getMessage());
		    return false;
	      }
	      return true;
	         
	}
	
	public boolean createTable() {
	    if (con == null)
	        return false;
	    
	    String sql = "CREATE TABLE IF NOT EXISTS Books (" +
	            "nazov varchar(255) PRIMARY KEY," +
	            "autor varchar(255) NOT NULL," +
	            "rokVydania integer NOT NULL," +
	            "dostupnost varchar(12) NOT NULL," +
	            "zaner varchar(255)," +
	            "vhodnyRocnik varchar(255)" +
	            ");";
	    
	    try {
			Statement stmnt = con.createStatement();
			stmnt.execute(sql);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	    
	
	public void insertRecord(String nazov, String autor, int rok,boolean dostupnost, Zaner zaner, String vhodnyRocnik ) {
        String sql = "INSERT INTO Books(nazov,autor,rokVydania,dostupnost,zaner,vhodnyRocnik) VALUES(?,?,?,?,?,?)";
        try {
            PreparedStatement pstmt = con.prepareStatement(sql); 
            pstmt.setString(1, nazov);
            pstmt.setString(2, autor);
            pstmt.setInt(3, rok);
            pstmt.setBoolean(4, dostupnost);
            if (zaner != null) {
                pstmt.setString(5, zaner.name());
            } else {
                pstmt.setNull(5, java.sql.Types.VARCHAR);
            }
            pstmt.setString(6, vhodnyRocnik);
            pstmt.executeUpdate();
        } catch (SQLException e) {
        	 System.out.println("Chyba pri vkladaní záznamu: " + e.getMessage());
             e.printStackTrace();
        }
    }
	
	public List<Books> getVsetkyKnihy(){
		List<Books> vsetkyKnihy = new ArrayList<>();
		String sql = "SELECT * FROM Books";
		try {
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery(sql);
	        while (rs.next()) {
	            String nazov = rs.getString("nazov");
	            String autor = rs.getString("autor");
	            int rok = rs.getInt("rokVydania");
	            boolean dostupnost = rs.getBoolean("dostupnost");
	            String zanerString = rs.getString("zaner");
	            Roman.Zaner zaner = zanerString != null ? Roman.Zaner.valueOf(zanerString) : null;
	            String vhodnyRocnik = rs.getString("vhodnyRocnik");
	            if (zaner != null) {
	            	vsetkyKnihy.add(new Roman(nazov, autor, rok, zaner, dostupnost));
	            } else {
	            	vsetkyKnihy.add(new Ucebnice(nazov, autor, rok, vhodnyRocnik, dostupnost));
	            }
	        }
	        rs.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return vsetkyKnihy;
	}
	
	/*public void selectAll(){
        String sql = "SELECT nazov, autor, rokVydania, stav, zaner, vhodnyRocnik plat FROM Books";
        try {
             Statement stmt  = con.createStatement();
             ResultSet rs    = stmt.executeQuery(sql);
             while (rs.next()) {
                	System.out.println(rs.getString("nazov") +  "\t" +  
                	rs.getString("autor") + "\t" + 
                	rs.getInt("rok") + "\t" + 
                	rs.getBoolean("dostupnost") + "\t" + 
                	rs.getString("zaner")+ "\t" + 
                	rs.getString("vhodnyRocnik"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}*/

	
	public void disconnect() { 
		if (con != null) {
		       try {     con.close();  } 
	               catch (SQLException ex) { 
	            	   System.out.println(ex.getMessage()); 
	            	   }
	               }
		}

}
