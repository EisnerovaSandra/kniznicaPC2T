package projektBP2T;

public class Books {
	private String nazovKnihy;
	private String autor;
	private int rokVydania;
	public boolean dostupnost = true;
	
	
	public Books(String nazovKnihy, String autor, int rokVydania, boolean dostupnost){
		this.nazovKnihy = nazovKnihy;
		this.autor = autor;
		this.rokVydania = rokVydania;
		this.dostupnost = dostupnost;
	}
	
	public String getNazov() {
		return nazovKnihy;
	}
	
	public void setNazov(String nazovKnihy) {
	    this.nazovKnihy = nazovKnihy;
	  }

	public String getAutora() {
		return autor;
	}
	
	public void setAutora(String autor) {
	    this.autor = autor;
	  }

	public int getRok() {
		return rokVydania;
	}
	
	public void setRok(int rokVydania) {
	    this.rokVydania = rokVydania;
	  }
	
	public boolean getDostupnost() {
		return dostupnost;
	}
		
	public void setDostupnost(boolean dostupnost) {
		this.dostupnost = dostupnost;
	}
}
