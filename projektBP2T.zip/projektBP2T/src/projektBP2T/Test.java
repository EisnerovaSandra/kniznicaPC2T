package projektBP2T;

import java.util.Comparator;
import java.util.Scanner;

public class Test {
	
	public static int jeCislo(Scanner sc) 
	{
		int cislo = 0;
		try
		{
			cislo = sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.println("zadejte prosim cislo");
			sc.nextLine();
			cislo = jeCislo(sc);
		}
		return cislo;
	
	}
	

    public static class NazovComparator implements Comparator<Books> {
        @Override
        public int compare(Books kniha1, Books kniha2) {
            return kniha1.getNazov().compareTo(kniha2.getNazov());
        }
    }
    
    public static class RokVydaniComparator implements Comparator<Books> {
        @Override
        public int compare(Books kniha1, Books kniha2) {
            return Integer.compare(kniha1.getRok(), kniha2.getRok());
        }
    }
    
    public static Books createBookFromLine(String riadok) {
        String[] cast = riadok.split(", ");
        
        if (cast.length < 5) {
            throw new IllegalArgumentException("Neplatný formát řádku: " + riadok);
        }

        String nazov = cast[0].split(": ")[1];
        String autor = cast[1].split(": ")[1];
        int rok = Integer.parseInt(cast[2].split(": ")[1]);
        boolean jeUcebnica = riadok.contains("vhodny pre rocnik");

        if (jeUcebnica) {
            String vhodnyRocnik = cast[3].split(": ")[1];
            boolean dostupnost = Boolean.parseBoolean(cast[4].split(": ")[1]);
            return new Ucebnice(nazov, autor, rok, vhodnyRocnik, dostupnost);
        } else {
            String zanerString = cast[3].split(": ")[1];
            Roman.Zaner zaner = null;
            
            switch (zanerString) {
                case "dobrodruzny":
                    zaner = Roman.Zaner.dobrodruzny;
                    break;
                case "historicky":
                    zaner = Roman.Zaner.historicky;
                    break;
                case "psychologicky":
                    zaner = Roman.Zaner.psychologicky;
                    break;
                case "fantasticky":
                    zaner = Roman.Zaner.fantasticky;
                    break;
                case "zivotopisny":
                    zaner = Roman.Zaner.zivotopisny;
                    break;
                default:
                    // Pokud není žánr rozpoznán, můžete vyvolat výjimku nebo udělat jinou vhodnou akci
                    throw new IllegalArgumentException("Neplatný žáner knihy: " + zanerString);
            }
            boolean dostupnost = Boolean.parseBoolean(cast[4].split(": ")[1]);
            return new Roman(nazov, autor, rok, zaner, dostupnost);
        }
    }
    
}
