package projektBP2T;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Scanner;


public class Databaze {
	
	static int moznost;
	static String nazov;
	static String autor;
	static String zaner;
	static int rok;
	static String vhodnyRocnik;
	static boolean dostupnost = true;
	static String porovnaj;
	static int vybranyZaner;
	static boolean pravda = false;
	static boolean pracujem = true;
	

	public static void main(String[] args) {
		
		DBConnection con = new DBConnection();
        if (con.connect()) {
            System.out.println("Databaze pripojena ");
            con.createTable();
        } else {
            System.out.println("Databaze neni pripojena ");
            return;
        }

        List<Books> kniznica = con.getVsetkyKnihy();
        if (kniznica != null) {
            System.out.println("Vsetky knihy nacitane z databazy");
        } else {
            System.out.println("Nepodarilo sa nacitat knihy z databazy");
            return;
        }

        Scanner sc = new Scanner(System.in);
        File file = new File("knihy.txt");
		
		while (pracujem) {
			
			Collections.sort(kniznica, new Test.NazovComparator());
			System.out.println("\n---Vyber moznost---");
			System.out.println("1. Pridat nove knihy");
			System.out.println("2. Upravit knihu");
			System.out.println("3. Vymazat knihu");
			System.out.println("4. Oznacit knihu ako pozicanu/vratenu");
			System.out.println("5. Vypis knih");
			System.out.println("6. Vyhladat knihu");
			System.out.println("7. Vypisat vsetky knihy podla autora");
			System.out.println("8. Vypisat vsetky knihy podla zanra");
			System.out.println("9. Vypisat vsetky pozicane knihy");
			System.out.println("10. Ulozit informacie o vybranej knihe do suboru");
			System.out.println("11. Nacitat vsetkych informacii o knihe zo suboru");
			System.out.println("12. Ukoncit program");
			moznost = Test.jeCislo(sc);
			
			switch(moznost) {
			case 1: 
				System.out.println("Aky zaner ma kniha?");
				System.out.println("1. Roman");
				System.out.println("2. Ucebnica");
				moznost = Test.jeCislo(sc);
				sc.nextLine();
				
				if(moznost == 1) {
					System.out.println("Zadajte nazov knihy:");
					nazov = sc.nextLine();
					
					System.out.println("Zadajte autora knihy:");
					autor = sc.nextLine();
					System.out.println("Zadajte rok vydania knihy:");
					rok = Test.jeCislo(sc);
					System.out.println("Vyberte zaner knihy z tychto moznosti: \n1. dobrodruzny    2. historicky    3. psychologicky    4. fantasticky    5. zivotopisny");
					
					while(true) {
						vybranyZaner = Test.jeCislo(sc);
						sc.nextLine();
						if(vybranyZaner < 1 || vybranyZaner > 5) {
							System.out.println("Neplatná volba zanru.");
							continue;
						}
						break;
					}
					
					Roman.Zaner zaner;
					switch (vybranyZaner) {
                    case 1:
                        zaner = Roman.Zaner.dobrodruzny;
                        break;
                    case 2:
                        zaner = Roman.Zaner.historicky;
                        break;
                    case 3:
                        zaner = Roman.Zaner.psychologicky;
                        break;
                    case 4:
                        zaner = Roman.Zaner.fantasticky;
                        break;
                    case 5:
                        zaner = Roman.Zaner.zivotopisny;
                        break;
                    default:
                        return;
					}
					kniznica.add(new Roman(nazov, autor, rok, zaner, dostupnost));
					break;
						
				} else if(moznost == 2) {
					System.out.println("Zadajte nazov knihy:");
					nazov = sc.nextLine();
					System.out.println("Zadajte autora knihy:");
					autor = sc.nextLine();
					System.out.println("Zadajte rok vydania knihy:");
					rok = Test.jeCislo(sc);
					System.out.println("Zadajte pre aky rocnik je kniha vhodna:");
					vhodnyRocnik = sc.next();
					kniznica.add(new Ucebnice(nazov, autor, rok, vhodnyRocnik, dostupnost));
					break;
					} else {
						while(moznost == 1 || moznost == 2) {
							System.out.println("Nezadali ste platne cislo.");
							sc.next();
						}
					}
				break;
			
			case 2:
				sc.nextLine();
				System.out.println("Zadajte nazov knihy, ktoru chcete upravit:");
				porovnaj = sc.nextLine();
				pravda = false;
				 for(Books kniha : kniznica) {
					if(kniha.getNazov().equalsIgnoreCase(porovnaj)) {
						pravda = true;
						
						while(true) {
							System.out.println("\nKtory udaj chcete upravit?");
							System.out.println("1. Autora   2.Rok vydania   3.Dostupnost");
							moznost = Test.jeCislo(sc);
							sc.nextLine();
						
								if(moznost == 1) {
									System.out.println("Zadajte noveho autora:");
									autor = sc.nextLine();
									kniha.setAutora(autor);
									break;
								} else if (moznost == 2) {
									System.out.println("Zadajte rok vydania:");
									rok = Test.jeCislo(sc);
									kniha.setRok(rok);
									break;
								} else if(moznost == 3) {
									System.out.println("Je kniha dostupna?");
									System.out.println("1. Ano   2.Nie");
									moznost = Test.jeCislo(sc);
									
									if(moznost == 1) {
										kniha.setDostupnost(true);
										break;
									} else if(moznost == 2) {
										kniha.setDostupnost(false);
										break;
									} else {
										System.out.println("Musite si vybrat jednu z moznosti");
										sc.next();
										continue;
									}
									
								} else {
									System.out.println("Musite si vybrat jednu z moznosti");
									sc.next();
									continue;
							}
							
						}
					}
				 }
				if (!pravda)
						System.out.println("Kniha s naznom " + porovnaj + " nebola najdena.");
				break;
				
					 
			case 3:
				sc.nextLine();
				System.out.println("Zadajte nazov knihy, ktoru chcete vymazat:");
				porovnaj = sc.nextLine();
				boolean vymazana = kniznica.removeIf(Books -> Books.getNazov().equalsIgnoreCase(porovnaj));
				
				if(vymazana)
					System.out.println("Kniha s nazvom " + porovnaj + " bola vymazana.");
				else
					System.out.println("Kniha s nazvom " + porovnaj + " sa nenachadza v systeme.");
				break;
				
			case 4:
				sc.nextLine();
				System.out.println("Zadajte nazov knihy, ktorej chcete zmenit stav na pozicanu/vratenu:");
				porovnaj = sc.nextLine();
				pravda = false;
				
				for(Books kniha : kniznica) {
					if(kniha.getNazov().equalsIgnoreCase(porovnaj)) {
						pravda = true;
						while(true) {
						System.out.println("Stav: \n1.Pozicana \n2. Vratena");
						int stav = Test.jeCislo(sc);
						if(stav == 1) {
							kniha.setDostupnost(false);
							System.out.println("Kniha s nazvom " + porovnaj + " bola uspesne oznacena ako nedostupna.");
							break;
						} else if(stav == 2) {						
							kniha.setDostupnost(true);
							System.out.println("Kniha s nazvom " + porovnaj + " bola uspesne oznacena ako dostupna.");
							break;
						}else
							System.out.println("Zadali ste chybnu moznost.");
						}
					}
				}
				if(!pravda)
					System.out.println("Kniha s naznom " + porovnaj + " nebola najdena.");
				break;
				
			case 5:
				for(Books kniha : kniznica) {
					System.out.println(kniha);
				}
				break;
				
			case 6:
				sc.nextLine();
				System.out.println("Zadajte nazov knihy, ktoru chcete najst:");
				porovnaj = sc.nextLine();
				pravda = false;
				 for(Books kniha : kniznica) {
					if(kniha.getNazov().equalsIgnoreCase(porovnaj)) {
						System.out.println("Udaje danej knihy v systeme:");
						System.out.println(kniha);
						pravda = true;
					}
				 }
				 if(!pravda)
					 System.out.println("Kniha s naznom " + porovnaj + " nebola najdena.");
				break;
				
			case 7:
				sc.nextLine();
				System.out.println("Zadajte cele meno autora, ktoreho knihy chcete najst:");
				porovnaj = sc.nextLine();
				pravda = false;
				Collections.sort(kniznica, new Test.RokVydaniComparator());
				
				 for(Books kniha : kniznica) {
					if(kniha.getAutora().equalsIgnoreCase(porovnaj)) {
						System.out.println(kniha);
						pravda = true;
					}
				 }
				 if(!pravda)
					 System.out.println("Autor s menom " + porovnaj + " nebol najdeny.");
				break;
				
			case 8:
				System.out.println("Vyberte zaner knihy z tychto moznosti: \n1. dobrodruzny    2. historicky    3. psychologicky    4. fantasticky    5. zivotopisny");
				vybranyZaner = sc.nextInt();
				for (Books kniha : kniznica) {
				    if (kniha instanceof Roman) {
				        Roman roman = (Roman) kniha;
				        try{
				        	
				        	if (roman.getZaner() == Roman.Zaner.values()[vybranyZaner - 1]) {
				            System.out.println(roman);
				        	}
				        	
				        } catch(java.lang.ArrayIndexOutOfBoundsException e) {
				        	System.out.println("Zadali ste neplatnu moznost.");
				        	break;
				        }
				    }
				}
				break;
				
			case 9:
				pravda = false;
				for(Books kniha : kniznica) {
					if(kniha.getDostupnost() == false) {
						if(kniha instanceof Roman)
							System.out.println("Roman: " + kniha);
						else if(kniha instanceof Ucebnice)
							System.out.println("Ucebnice: " + kniha);
						pravda = true;
					}
				}
				if(!pravda)
					System.out.println("Ziadna kniha nie je momentalne pozicana.");
				break;
			
			case 10:
		        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
		            for (Books kniha : kniznica) {
		                writer.write(kniha.toString()); 
		                writer.newLine();
		            }
		            System.out.println("Zoznam knih bol uspesne zapisany do suboru.");
		        } catch (IOException e) {
		            System.err.println("Nastala chyba pri zapise do suboru: " + e.getMessage());
		        }
				break;
			case 11:

		        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
		            String riadok;
		            while ((riadok = reader.readLine()) != null) {
		            	boolean exists = false;
		                for (Books existingBook : kniznica) {
		                    if (existingBook.getNazov().equals(Test.createBookFromLine(riadok).getNazov())) {
		                        exists = true;
		                        break;
		                    }
		                }
		                if (!exists) {
		                    Books kniha = Test.createBookFromLine(riadok);
		                    kniznica.add(kniha);
		                }
		            }
		            System.out.println("Seznam knih byl úspěšně načten ze souboru.");
		        } catch (IOException e) {
		            System.err.println("Nastala chyba při čtení ze souboru: " + e.getMessage());
		        }
				
				break;
				
			case 12:
				List<Books> vsetkyKnihy = con.getVsetkyKnihy();
				for(Books kniha : kniznica) {
					boolean knihaExistujeVDatabaze = false;
				    for (Books existingBook : vsetkyKnihy) {
				        if (existingBook.getNazov().equals(kniha.getNazov())) {
				            knihaExistujeVDatabaze = true;
				            break;
				        }
				    }
				    if (!knihaExistujeVDatabaze) {
				    	if(kniha instanceof Roman) {
				    		Roman roman = (Roman) kniha;
				    		String zanerValue = roman.getZaner().name();
				    		con.insertRecord(kniha.getNazov(), kniha.getAutora(), kniha.getRok(), kniha.getDostupnost(), Roman.Zaner.valueOf(zanerValue), null);
				    	} else if(kniha instanceof Ucebnice) {
				    		Ucebnice ucebnice = (Ucebnice) kniha;
				    		con.insertRecord(kniha.getNazov(), kniha.getAutora(), kniha.getRok(), kniha.getDostupnost(), null , ucebnice.getVhodnyRocnik());
				    	}
				    }
				}
				con.disconnect();
				pracujem = false;
				break;
	
			default:
				System.out.println("Vyberte si moznost medzi 1 az 12.");
			}
		}
	}
}
