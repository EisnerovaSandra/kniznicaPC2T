package projektBP2T;

public class Ucebnice extends Books{
	
	private String vhodnyRocnik;

	public Ucebnice(String nazovKnihy, String autor, int rokVydania, String vhodnyRocnik, boolean dostupnost) {
		super(nazovKnihy, autor, rokVydania, dostupnost);
		this.vhodnyRocnik = vhodnyRocnik;
	}
	
	public String getVhodnyRocnik() {
		return vhodnyRocnik;
	}
	
	public void setVhodnyRocnik(String vhodnyRocnik) {
		this.vhodnyRocnik = vhodnyRocnik;
	  }
	
	@Override
	public String toString() {
		return "Nazov knihy: " + getNazov() + ", autor: " + getAutora() + ", rok vydania: " + getRok() + ", vhodny pre rocnik: " + getVhodnyRocnik() + ", dostupnost: " + getDostupnost();
	}
	

}
